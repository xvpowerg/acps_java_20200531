
public class HomeWork1 {

	static int f(int n) {
		if (n == 1 || n==2) {
			return 1;
		}
		return f(n-1) +f(n-2);
	}
		
	public static void main(String[] args) {
		int ans = f(6);
		System.out.println(ans);
	   // 1 2 3 4 5 6 
		//1 1 2 3 5 8
	//n
	//n = f(n-1) + f(n-2)	
	//5--> f(5-1) +f(5-2) = f(4) + f(3) = 3 + 2 = 5  
	//4-->= f(4-1) +f(4-2) = f(3) +f(2) = 2 + 1= 3
	//3--> f(3-1) + f(3-2) = f(2) + f(1)
	//f(2) = 1	
	//f(1) = 1
		
	}

}
