
public class Ch5_3 {

	public static void main(
			String[] args) {
		// TODO Auto-generated method stub
//		Book book1 = new Book(); 
//		book1.isbn = "isbn123456";
//		book1.name = "Android ";
//		book1.price = 567;
//		book1.print();
//		Book book2 = new Book("isbn5678",
//				650,"Java");
//		book2.print();
		
		Book book3 = new Book(); 
		book3.print();
	}

}
