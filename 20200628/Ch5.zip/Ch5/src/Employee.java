
public class Employee {
   private int[] vacationDays = {10,15,15,15,20,20,25};
   private int year;
   Employee(int year){
	   this.year = year;
   }
   public int getVacation() {
	   	if (year< 0 ) year = 0;   
	   if (year<= 5) {
		   return vacationDays[year];
	   }
	   return vacationDays[vacationDays.length - 1];
   }
   
}
