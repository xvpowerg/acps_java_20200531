
public class Ch5_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle cr = new Circle(20); 	
		System.out.println(cr.getArea());
		System.out.println(Circle.area(12));
		System.out.println(Circle.area(50));
		System.out.println(Circle.PI);
	}

}
