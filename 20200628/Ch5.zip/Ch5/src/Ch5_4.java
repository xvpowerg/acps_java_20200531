
public class Ch5_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//�ʸ�
	   Book b1 = new Book();
	   b1.setPrice(-500);
	   //b1.isbn = "1";
	   b1.setIsbn(null);
	   b1.print();
	}

}
