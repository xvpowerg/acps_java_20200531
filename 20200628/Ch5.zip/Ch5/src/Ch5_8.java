
public class Ch5_8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] array = new int[2][3];
		array[0][1] = 36;
		array[1][2] = 75;
		array[0][2] = 63;
		
		for (int i =0 ; i <array.length ;i++) {
			int[] tmpArray = array[i];
			for (int k = 0; k <tmpArray.length ;k++) {
				System.out.print(tmpArray[k]+" ");
			}
			System.out.println();
		}
		
		
		for (int[] tmpArray : array) {
			for (int v : tmpArray) {
				System.out.print(v+" ");
			}
			System.out.println();
		}
		
	}

}
