
public class Student {
	int id;
	String name;
	float height;
	
	Student(int inId,String name,float height){
		id = inId;
		this.name = name;
		this.height = height;
	}
	void print(){
		System.out.println(id+":"+name+":"+height);
	}
}
