
public class Ch5_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] scores = new int[5];
		scores[0] = 90;
		scores[1] = 82;
		scores[3] = 70;
		scores[4] = 65;
		
		for (int i =0; i <scores.length ;i++) {
			System.out.print(scores[i]+" ");
		}
		System.out.println();
		//foreach
		for (int v : scores) {
			System.out.print(v+" ");
		}
		
//		for (int i = 0;i < scores.length;i++) {
//			int v = scores[i];
//			System.out.print(v+" ");
//		}
		
	}

}
