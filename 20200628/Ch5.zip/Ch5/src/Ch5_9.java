import java.util.ArrayList;
public class Ch5_9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList(5000);
		//�s�W���e
		list.add("Ken");
		list.add("Vivin");
		list.add("Join");//2
		list.add("Iris");
		
		for (int i = 0; i < list.size();i++) {
			System.out.print(list.get(i)+" ");
		}
		System.out.println();
		list.set(2, "Lucy");
		for (Object n : list) {
			System.out.print(n+" ");	
		}
		System.out.println();
		list.remove(3);
		for (Object n : list) {
			System.out.print(n+" ");	
		}
		System.out.println();
		//�P�_�Y����O�_�s�b��ثeList����
	boolean b1 = list.contains("Vivin");
	System.out.println(b1);
	 boolean isEmpty =  list.isEmpty();
	 System.out.println(isEmpty);
	 //��ثeList���Y����Index
	 int index = list.indexOf("Lucy");
	 System.out.println(index);
	 //index�䤣��^��-1
	 index = list.indexOf("Join");
	 System.out.println(index);
	}

}
