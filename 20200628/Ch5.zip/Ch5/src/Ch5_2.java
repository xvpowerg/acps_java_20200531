
public class Ch5_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 20:Ken:180
		Student st1 = 
				new Student(20,"Ken",180);
		st1.print();
	}

}
