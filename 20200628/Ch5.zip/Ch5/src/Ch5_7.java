
public class Ch5_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] days = {10,15,20,25};
		System.out.println(days[2]);
		//0 10
		//1~3 15
		//4~5 20
		//6 25
		Employee ep = new Employee(5);
		System.out.println(ep.getVacation());
	}

}
