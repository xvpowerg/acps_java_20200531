
public class Ch6_9 {
	
	//throws Exception  �i��|�o�ͬƻ�Exception
	//throw new Exception �ҥ~�o�ͤF
	//�����ncatch 
	public static void testException()throws Exception {
	
		throw new Exception("Test Exception");	
	}
	//���@�w�ݭncatch
	public static void testRuntimeException()throws RuntimeException {
		
		throw new RuntimeException("Test RuntimeException");
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			testException();
		}catch(Exception ex) {
			System.out.println(ex);
		}
		
		try {
			testRuntimeException();	
		}catch(RuntimeException ex) {
			System.out.println(ex);
		}
		
		
	}

}
