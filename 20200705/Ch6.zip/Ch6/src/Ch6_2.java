
public class Ch6_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String values = "Ken,Vivin,Tom";
		System.out.println(values.charAt(0));
		System.out.println(values.charAt(1));
		System.out.println(values.charAt(5));
		// �����k�j�M�I��Ĥ@�Ӧr���N�^��
		int index = values.indexOf("i");
		System.out.println(index);
		index = values.indexOf("i", index+1);
		System.out.println(index);
		
	
		
		
	}

}
