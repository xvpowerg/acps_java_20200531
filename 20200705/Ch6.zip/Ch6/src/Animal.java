
//�κ����� �i�H���ܬ���H
public abstract class Animal implements Run {
	private String name;
	private int height;
	
	public Animal() {
		
	}
	public Animal(String name, int height) {
		super();
		this.name = name;
		this.height = height;
	}
	//abstract �a�b��k���t�N 
	//bark �b�~�ӫᤣ�n�ѤF�мg
	public abstract void bark();
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	

	
	
}
