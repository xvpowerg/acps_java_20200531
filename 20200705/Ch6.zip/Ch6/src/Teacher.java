
public class Teacher  extends Person{
	public Teacher(String name,float height,float weight ){
		super(name,height,weight);
	}
	
	public String getName() {
		return "TE:"+ super.getName();
	}
	
	public String toString() {
		return this.getName()+":"+this.getHeight()+":"+this.getWeight();
	}
	
	public boolean equalse(Object obj) {
		Teacher tmpT = (Teacher)obj;
		return this.getName().equals(tmpT.getName()) && 
				this.getHeight() == tmpT.getHeight() && 
				this.getWeight() == tmpT.getWeight();
	}
}
