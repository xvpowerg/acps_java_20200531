import java.util.Scanner;
public class Ch6_3 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		String input = scan.nextLine();
		System.out.println(input);
		//split ���Φr��
		String[] inValues = input.split(" ");
		//8 15 2
		System.out.println(inValues[0]);
		System.out.println(inValues[1]);
		System.out.println(inValues[2]);
		
		
	}

}
