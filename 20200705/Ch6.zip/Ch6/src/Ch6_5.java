
public class Ch6_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		String values = "";
//		for (int i =1;i<=5;i++) {
//			values += i;
//			if (i < 5) {
//				values += ",";	
//			}
//		}
//		System.out.println(values);
		
		StringBuilder sb = new StringBuilder();
		for (int i =1;i<=5;i++) {
			sb.append(i) ;
			if (i < 5) {
				sb.append(",") ;	
			}
		}
		System.out.println(sb.toString());
		
	}



}
