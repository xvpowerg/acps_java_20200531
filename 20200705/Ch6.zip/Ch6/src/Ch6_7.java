import java.util.ArrayList;

public class Ch6_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p1 = new Person("Ken",175,67);
		System.out.println(p1.getName());
		System.out.println(p1.getHeight());
		
		Student st = new Student("Vivin",158,52);
		st.addScore(100);
		st.addScore(75);
		st.addScore(96);
		
		Teacher t1 = new Teacher("Lindy",165,61);
		
		//�ڧƱ�Student �b getName���ɭ����ڥ[�WST:xxxx
		//�ڧƱ�Teacher �b getName���ɭ����ڥ[�WTE:xxxx
		
		System.out.println(st.getName());
		System.out.println(st.getHeight());
		st.printScore();
		System.out.println();
		System.out.println(t1.getName());
		System.out.println(t1.getHeight());
		
		
		System.out.println(st);
		System.out.println(t1);
		
	}

}
