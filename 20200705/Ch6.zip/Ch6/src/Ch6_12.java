
public class Ch6_12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//�h��
		Animal animal = new Dog("Nana",5);
		animal.bark();
		animal.runing();
	}

}
