package net;

import db.DBConnection;

public class Ch6_11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DBConnection db = new DBConnection("mydb","127.0.0.1");
		System.out.println(db);
		//�]���b���Ppackage�ҥH�nimport
		FileDownload download = new FileDownload("C:\\mydir",
				"http://www.myfile.com/image.jpg");
		System.out.println(download.size);
	}

}
