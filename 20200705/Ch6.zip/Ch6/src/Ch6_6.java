import java.util.Scanner;
public class Ch6_6 {
		
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String input = scan.nextLine();
		String[] inputItem =  input.split(" ");
		//���J�����ԧB�Ʀr��r�ର�򥻫��A
		int loop1 = Integer.parseInt(inputItem[0]);
		int loop2 = Integer.parseInt(inputItem[1]);
		
		for (int i =1;i <=loop1 ;i++) {
			System.out.print(i+" ");
		}
		System.out.println();
		for (int i =1;i <=loop2 ;i++) {
			System.out.print(i+" ");
		}
		
		

	}

}
