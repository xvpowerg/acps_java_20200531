
public interface Run {
	void runing();
}
