
public class Ch6_8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Student st1 = new Student("Ken",178,65);
			Student st2 = new Student("Ken",178,65);
			System.out.println(st1.equals(st2));
			try {
				st2.addScore(-500);
			}catch(RuntimeException ex) {
				System.out.println(ex);
			}
			
			
			System.out.println("==========");
	}

}
