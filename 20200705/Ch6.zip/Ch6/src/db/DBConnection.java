package db;

public class DBConnection {
	//private �u��b�ثe���O�s��
	private String dbName;
	private String localhost;
	//��package�L�k�s��
	int count;
	//public �Ҧ��a�賣�i�s��
	public DBConnection(String dbName, String localhost) {
		super();
		this.dbName = dbName;
		this.localhost = localhost;
	}
	
	public String getDbName() {
		return dbName;
	}
	public void setDbName(String dbName) {
		this.dbName = dbName;
	}
	public String getLocalhost() {
		return localhost;
	}
	public void setLocalhost(String localhost) {
		this.localhost = localhost;
	}
	
	@Override
	public String toString() {
		return "DBConnection [dbName=" + dbName + ", localhost=" + localhost + "]";
	}

	 	
	

}
