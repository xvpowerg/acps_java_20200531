package db;
import net.FileDownload;
public class Ch6_10 {
	
	public static void main(String[] args) {		
		DBConnection db = new DBConnection("mydb","127.0.0.1");
		System.out.println(db.count);
		//�]���b���Ppackage�ҥH�nimport
		FileDownload download = new FileDownload("C:\\mydir",
				"http://www.myfile.com/image.jpg");
		System.out.println(download);
	}

}
