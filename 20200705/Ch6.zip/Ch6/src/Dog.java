
public class Dog extends Animal  {		
	public Dog() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Dog(String name, int height) {
		super(name, height);
		// TODO Auto-generated constructor stub
	}

		public void bark() {
			System.out.println("�L�L!!");
		}
		
		public void runing() {
			System.out.println("�]�]�]!!!");
		}
}
