
public class Ch3_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int f1 = 0;
		int f2 = 1;
		//f >= 2
		int f = 8;
		while(--f >= 1) {
			int tmp = f2;
			f2 += f1;
			f1 = tmp;
		}
		System.out.println(f2);
	}

}
