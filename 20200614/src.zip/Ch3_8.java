import java.util.*;
public class Ch3_8 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("�п�J���G");
		int h = scan.nextInt();
		System.out.println("�п�J�e�G");
		int w = scan.nextInt();
		
		for (int i=1; i<= w; i++) {
			for (int k =1;k<=h;k++) {
				System.out.print("@");
			}
			System.out.println();
		}
		
		

	}

}
