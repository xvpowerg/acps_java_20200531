import java.util.Scanner;
public class Ch3_2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("�п�J���ū�:");		
		int c = scan.nextInt();
		int f = 9 / 5 * c + 32;
		System.out.println(f);
		
	}
}
