import java.util.Scanner;
public class Ch3_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		int price = scan.nextInt();
		if (price < 2000) {
			price *= 0.9;
		}else if(price < 3000) {
			price *= 0.85;
		}else if(price < 5000) {
			price *= 0.8;
		}else if(price >= 5000) {
			price *= 0.7;
		}
		System.out.println(price);
	}

}
