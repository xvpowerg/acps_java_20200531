
public class Ch3_10 {

	public static void main(String[] args) {
	    myTag1:
		for (int i =1;i<=5;i++) {
			System.out.println("Inner Start:"+i);
			for (int k = 1;k<=3; k++) {		
				if (i == 3) {
					System.out.println("Bye!!");
					//break myTag1;
					continue myTag1;
				}
				System.out.print(i+"_"+k+" ");				
			}
			System.out.println();
			System.out.println("Inner End:"+i);
		}	
	}
}
