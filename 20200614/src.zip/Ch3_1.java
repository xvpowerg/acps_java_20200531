
public class Ch3_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		short a = 1,b=2;
		short c =(short)( a + b);		
		System.out.println(c);
	}

}
