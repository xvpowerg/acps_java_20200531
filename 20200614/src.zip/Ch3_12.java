
public class Ch3_12 {
	
	static void swap(int a,int b) {
		int tmp = a;
		a = b;
		b = tmp;
	}
	
	static void swap(int[] array) {
		int tmp = array[0];
		array[0] = array[1];
		array[1]= tmp; 
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//�򥻫��A
		int a = 5,b = 2;
//		int tmp = a;
//		a = b;
//		b = tmp;
		swap(a,b);
		System.out.println(a+":"+b);
		//�Ѧҫ��A
		int[] array = {7,11};
//		int tmp = array[0];
//		array[0] = array[1];
//		array[1]= tmp; 
		swap(array);
		System.out.println(array[0]+":"+array[1]);
	}

}
