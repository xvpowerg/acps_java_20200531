import java.util.Scanner;
public class Ch3_3 {

	public static void main(String[] args) {
			
		Scanner scan = new Scanner(System.in);		
		int n = scan.nextInt();
		String msg = n%2 == 0? "����": "�_��";
		System.out.println(msg);
	}

}
