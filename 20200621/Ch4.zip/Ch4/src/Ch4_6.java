
public class Ch4_6 {

		static int factorial( int n) {
			int result = 1;
			for (int i =1;i<=n;i++) {
				result *= i;
			}
			
			return result;
		}
		static int factorial2(int n) {
			if (n == 0) {
				return 1;
			}			
			return n * factorial2(n-1);
		}
	
	public static void main(String[] args) {
		
		 System.out.println(factorial(7));
		 System.out.println(factorial2(7));
	}
	//0   1   2   3   4   5
	//1 * 1 * 2 * 3 * 4 * 5 
	
    // 5! = 5 * 4! = 120  
	// 4! = 4 * 3! = 24
	// 3! = 3 * 2! = 6
	// 2! = 2 * 1! = 2
	// 1! = 1 * 0! = 1
}
