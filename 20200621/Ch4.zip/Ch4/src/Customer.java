
public class Customer {
	int customerID = 0;
	String name = "-name required-";
	String address = "address required-";
	String phoneNumber = "-phone required-";
	String eMail = "-email optional-";

	public  void setCustomerInfo(int id, String nm, String addr, String phNumber) {
		setCustomerInfo(id,nm,addr,phNumber,eMail);
	}
	
	public  void setCustomerInfo(int id, String nm, String addr,
								String phNumber,String email) {
		customerID = id;
		name = nm;
		address = addr;
		phoneNumber = phNumber;
		eMail = email;		
	}	
	public void display() {
		//f = Format
		//%d ���ܾ�� %s ���ܦr�� %n �i�󥭥x�q��
		System.out.printf("Customer Id:%d%n "
				+ "Customer Name:%s%n "
				+ "Customer address:%s%n "
				+ "Customer phoneNumber:%s%n "
				+ "Customer email:%s%n",
				customerID,name,address,phoneNumber,eMail);	
	
	}

}
