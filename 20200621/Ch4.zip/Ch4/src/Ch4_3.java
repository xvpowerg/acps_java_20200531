
public class Ch4_3 {
	public static void main(String[] args) {
		
		Customer c1 = new Customer();
		Customer c2 = new Customer();
		
		c1.setCustomerInfo(1, "Howard", "�|����xxx��","0911778225");
		c2.setCustomerInfo(2, "Ken", "���ڸ�", "02225882","test@gmail.com");
		c1.display();
		c2.display();
	}
}
