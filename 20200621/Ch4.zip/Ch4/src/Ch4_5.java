
public class Ch4_5 {
	//1~5
	static void testRecursion(int n) {
		System.out.println("Start:"+n);
		if (n <= 5) {
		   System.out.println(n);
		   testRecursion(n +1);
		}
		System.out.println("End:"+n);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		testRecursion(1);		
	}

}
