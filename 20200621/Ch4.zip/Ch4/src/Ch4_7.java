
public class Ch4_7 {
		//m = �Q���ơ@���װ���
		static int gcd(int m,int n) {			
			int r = 0;
			while(n != 0) {
				r = m % n;
				m = n;
				n = r;
			}			
			return m;
		}
static int gcd2(int m,int n) {
	
	if (n==0) {
		return m;
	}
	return gcd2(n,m % n);
}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(gcd(20,14));
		System.out.println(gcd2(20,14));
	}

}
// m = 20 n = 14 �l��:6
// m= 14 n = 6 �l��:2
// m = 6 n = 2 �l��:0
// m = 2 n = 0 