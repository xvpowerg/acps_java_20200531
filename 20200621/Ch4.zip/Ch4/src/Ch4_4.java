
public class Ch4_4 {
//	static int sum() {
//		return sum(0,0,0);
//	}
//	static int sum(int a,int b) {
//		return sum(a,b,0);
//	}
//	static int sum(int a,int b,int c) {
//		return a + b +c;
//	}
	//Varargs
	static int sum(int ... values) {
		int result = 0;
		//foreach �j��
		for (int v : values) {
			System.out.println("v:"+v);
			result += v;
		}
		return result;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(sum(5,2));
//		System.out.println(sum(5,2,9));
//		System.out.println(sum(5,2,9,1,6,7,8,9,1,23,5,7));
		System.out.println(sum());//0
		//���]�ڪ��ѼƼƶq�On >=0  Varargs
		
	
	}

}
