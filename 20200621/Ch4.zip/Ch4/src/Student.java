
public class Student {
	static String name;
	int age;
	
	Student(String inName,int inAge){
		name = inName;
		age = inAge;
	}
	public void info() {
		System.out.println(name+":"+age);
	}
	
	
}
