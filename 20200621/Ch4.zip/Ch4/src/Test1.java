
public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//			String day = "";
//			switch(day) {
//			case "Mon":
//				System.out.println("���^");
//				break;
//			case "Tue":
//				System.out.println("���");
//				break;
//			case "Wed":
//				break;
//			}
		//�p��O�_�����
//		int n = 13;
//		boolean test = true;
//		for (int i = 2;i< n;i++) {
//			if (n % i == 0) {
//				test = false;
//				break;
//			}
//		}
//		
//		if (test) {
//			System.out.println("���");
//		}else {
//			System.out.println("�D���");
//		}
		
		int n = 13;
		String msg = "���";
		for (int i = 2;i< n;i++) {
			if (n % i == 0) {
				msg = "���O���";
				break;
			}
		}
		 System.out.println(msg);
	}

}
