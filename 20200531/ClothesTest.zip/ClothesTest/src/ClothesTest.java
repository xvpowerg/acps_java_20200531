
public class ClothesTest {
    public static void main(String[] args) {
    		Clothes c = new Clothes();
    		c.dispalyInfo();
    }
}
