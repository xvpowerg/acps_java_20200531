
public class Clothes {
	char colorCode;
	String description;
	double price;
	
	//�ڬO��k
    void dispalyInfo() {
    	
    }
}
