
public class Ch2_4 {

	public static void main(String[] args) {
		//count+1���� �b������
				int count = 0;
				System.out.println(++count);
				System.out.println(++count);
				
				//count+1���e ������
				System.out.println(count++);
				System.out.println(count++);
				System.out.println("Final Count:"+count);
				
			int a =0, b=0;
			b = a-- - --a;
			 // 0  a=-1   a = -1 - 1 a = -2
			// b = 0 - (-2)
			System.out.println(a+":"+b);
		
			
				
	}

}
