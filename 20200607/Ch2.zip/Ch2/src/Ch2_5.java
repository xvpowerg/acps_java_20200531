
public class Ch2_5 {

	public static void main(String[] args) {
		int a = 10,b=5;
		//& �L�u���{�H
		boolean bool = (a++ >10) & (b--<5);
		//               10 > 10    5 < 5
		//                 F         F    
		//                      a= a +1  b=b-1; 
		//                      a = 11   b=4
		System.out.println(a);
		System.out.println(b);
		System.out.println(bool);
		
		

	}

}
