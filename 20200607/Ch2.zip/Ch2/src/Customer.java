
public class Customer {
     int id;
     String name;
     String email;
     void displayCustomerInfo() {
    	 System.out.println("Customer ID:"+id);
    	 System.out.println("Name:"+name);
    	 System.out.println("Email:"+email);
     }
}
