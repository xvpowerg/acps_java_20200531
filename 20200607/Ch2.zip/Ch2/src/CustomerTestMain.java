
public class CustomerTestMain {
    public  static void main(String[] args) {
    		Customer c1 = new Customer();//AAA
    		c1.id = 1;
    		c1.name = "Ken";
    		c1.email = "cccc@gmail.com";
    		Customer c2 = new Customer();//BBB
    		c2.id = 2;
    		c2.name = "Vivin";
    		c2.email = "yyyy@gmail.com";
    		
    		c1.displayCustomerInfo();
    		c2.displayCustomerInfo();
    		
    		c2 = c1;
    		
    		c1.displayCustomerInfo();
    		c2.displayCustomerInfo();
    		
    	
    }
}
