
public class Ch2_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//count+1���� �b������
		int count = 0;
		count = count + 1;
		System.out.println(count);
		count = count + 1;
		System.out.println(count);
		
		//count+1���e ������
		System.out.println(count);
		count = count + 1;
		System.out.println(count);
		count = count + 1;
		
		System.out.println("Final Count:"+count);
	}

}
