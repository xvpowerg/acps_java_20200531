import java.awt.Color;

import ch.aplu.turtle.*;
public class TestTurtleMain {
   public static void main(String[] args) {
	   
	   Turtle t1 = new Turtle();
	   t1.setColor(Color.GREEN);
	   t1.setPos(50, -50);
	   t1.setLineWidth(2.0);
	   
	   for (int i = 1; i<=4;i++) {
		   t1.forward(100);
		   t1.left(90);
	   }
	   
	   
	   
	   
	 
	   
	   
   }
}
